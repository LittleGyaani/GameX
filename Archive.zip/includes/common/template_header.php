<?php

  //Define Base URL to be used globally
  $baseURL = 'http://localhost/GameX/';//http://www.battlestation.live/

  //Allow Cross Access from Origin
  header("Access-Control-Allow-Origin: *");

 ?>
<!-- Meta updated by LittleGyaani(BRAHMA) {https://www.twitter.com/LittleGyaani} -->
<!-- Meta, Header and Navigation Start-->
<!-- Required Meta Tags Always Come First -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="x-ua-compatible" content="ie=edge">

<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo $baseURL; ?>favicon.ico">
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans%3A400%2C300%2C500%2C600%2C700%7CPlayfair+Display%7CRoboto%7CRaleway%7CSpectral%7CRubik">
<!-- CSS Global Compulsory -->
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/vendor/bootstrap/bootstrap.min.css">
<!-- CSS Global Icons -->
<!-- <link rel="stylesheet" href="<?php echo $baseURL; ?>assets/vendor/icon-awesome/css/font-awesome.min.css"> -->
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="stylesheet" href="http://simplelineicons.com/css/simple-line-icons.css">
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/vendor/icon-etlinefont/style.css">
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/vendor/icon-line-pro/style.css">
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/vendor/icon-hs/style.css">
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/vendor/animate.css">
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/vendor/malihu-scrollbar/jquery.mCustomScrollbar.min.css">
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/vendor/hs-megamenu/src/hs.megamenu.css">
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/vendor/hamburgers/hamburgers.min.css">

<!-- CSS Unify -->
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/css/unify-core.css">
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/css/unify-components.css">
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/css/unify-globals.css">

<!-- CSS Customization -->
<link rel="stylesheet" href="<?php echo $baseURL; ?>assets/css/custom.css">

<!-- CSS Implementing Plugins -->
<link  rel="stylesheet" href="<?php echo $baseURL; ?>assets/vendor/custombox/custombox.min.css">

<!-- Custom Toast Notification powered by Cheers Alert -->
<script src="https://maddumajohnerick.github.io/cheers-alert/dist/cheers-alert.min.js"></script>
<link rel="stylesheet" href="https://maddumajohnerick.github.io/cheers-alert/dist/cheers-alert.min.css" />


<!-- Heartbeat Style -->
<style>
.fa-beat {
  animation:fa-beat 5s ease infinite;
}
@keyframes fa-beat {
  0% {
    transform:scale(1);
  }
  5% {
    transform:scale(1.25);
  }
  20% {
    transform:scale(1);
  }
  30% {
    transform:scale(1);
  }
  35% {
    transform:scale(1.25);
  }
  50% {
    transform:scale(1);
  }
  55% {
    transform:scale(1.25);
  }
  70% {
    transform:scale(1);
  }
}

.heart {
  color:red;
}
#notification_li
{
position:relative
}
#notificationContainer
{
background-color: #fff;
border: 1px solid rgba(100, 100, 100, .4);
-webkit-box-shadow: 0 3px 8px rgba(0, 0, 0, .25);
overflow: visible;
position: absolute;
top: 30px;
margin-left: -170px;
width: 400px;
z-index: -1;
display: none; // Enable this after jquery implementation
}
// Popup Arrow
#notificationContainer:before {
content: '';
display: block;
position: absolute;
width: 0;
height: 0;
color: transparent;
border: 10px solid black;
border-color: transparent transparent white;
margin-top: -20px;
margin-left: 188px;
}
#notificationTitle
{
font-weight: bold;
padding: 8px;
font-size: 13px;
background-color: #ffffff;
position: fixed;
z-index: 1000;
width: 384px;
border-bottom: 1px solid #dddddd;
}
#notificationsBody
{
padding: 33px 0px 0px 0px !important;
min-height:300px;
}
#notificationFooter
{
background-color: #e9eaed;
text-align: center;
font-weight: bold;
padding: 8px;
font-size: 12px;
border-top: 1px solid #dddddd;
}
#nav{list-style:none;margin: 0px;padding: 0px;}
#nav li {
float: left;
margin-right: 5px;
font-size: 14px;
font-weight:bold;
}
#nav li a{color:#333333;text-decoration:none}
#nav li a:hover{color:#006699;text-decoration:none}
.parent{
position:relative;
height:300px;
width:300px;
background:#eee;
overflow:hidden;
padding-right:10px;
}
.scrollable{
position:absolute;
top:0px;
width:300px;
}
.scrollbar{
cursor:n-resize;
position:absolute;
top:0px;
right:0px;
z-index:2;
background:#444;
width:10px;
border-radius:0px;
cursor: pointer;
}

</style>
<!--Heartbeat End-->

</head>

<body>

<main>



  <!-- Header -->
  <header id="js-header" class="u-header u-header--sticky-top u-header--toggle-section u-header--change-appearance" data-header-fix-moment="300">
  <div class="u-header__section u-header__section--dark g-bg-black g-transition-0_3 g-py-10" data-header-fix-moment-exclude="g-py-10" data-header-fix-moment-classes="g-py-0">
      <nav class="js-mega-menu navbar navbar-expand-lg hs-menu-initialized hs-menu-horizontal">
        <div class="container">
          <!-- Responsive Toggle Button -->
          <button class="navbar-toggler navbar-toggler-right btn g-line-height-1 g-brd-none g-pa-0 g-pos-abs g-top-3 g-right-0" type="button" aria-label="Toggle navigation" aria-expanded="false" aria-controls="navBar" data-toggle="collapse" data-target="#navBar">
            <span class="hamburger hamburger--slider">
          <span class="hamburger-box">
            <span class="hamburger-inner"></span>
            </span>
            </span>
          </button>
          <!-- End Responsive Toggle Button -->

            <div id="hiddenUserID" style="display:none;"><?=$userID?></div>


            <!-- Logo -->
            <a href="<?php echo $baseURL; ?>index.php" class="navbar-brand d-flex">
                <h2><font color="green"><b>battle</b><strong>station</strong></font></h2>
            </a>
            <!-- End Logo -->

            <?php

            //Get current url for showing headers on pages accordingly
            $current_url = strtolower(basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)));

              if(!($_SESSION['userID'])){

            ?>
              <div class="d-inline-block g-pos-rel g-valign-middle g-pl-30 g-pl-0--lg">
                <a class="btn u-btn-outline-primary g-font-size-13 text-uppercase g-py-10 g-px-15" href="<?php echo $baseURL; ?>portal/web/auth/loginPage.php">Login/Signup</a>
              </div>

            <?php

            }else{

              if($current_url == 'index.php' || $current_url == 'gamex' || $current_url == 'index'){

              ?>
              <!-- Navigation -->
            <div class="collapse navbar-collapse align-items-center flex-sm-row g-pt-10 g-pt-5--lg" id="navBar">
              <ul class="navbar-nav text-uppercase g-font-weight-600 ml-auto">
                <li class="nav-item g-mx-20--lg">
                  <a href="#!" class="nav-link px-0">Home

              </a>
                </li>
                <li class="nav-item g-mx-20--lg">
                  <a href="#!" class="nav-link px-0">Features

              </a>
                </li>
                <li class="nav-item g-mx-20--lg active">
                  <a href="#!" class="nav-link px-0">Shortcodes
                <span class="sr-only">(current)</span>
              </a>
                </li>
                <li class="nav-item g-mx-20--lg">
                  <a href="#!" class="nav-link px-0">Pages

              </a>
                </li>

              </ul>

            <!-- End Navigation -->

              <div class="d-inline-block g-pos-rel g-valign-middle g-pl-30 g-pl-0--lg">
                <a class="btn btn-md u-btn-outline-cyan g-brd-2 g-mr-10 g-mb-15" href="portal/web/userProfile/myProfile.php">Welcome <b><?= $selectUserInformations['user_fullname'];?></b></a> <a href="portal/web/auth/controller/userLogout.php" class="btn btn-md u-btn-outline-lightred g-mr-10 g-mb-15">Logout</a>
              </div>
              <?php

            }else{?>
              <!-- User AREA-->
              <div class="d-inline-block g-pos-rel g-valign-middle g-pl-30 g-pl-0--lg">

                <font color="white"><i class="icon-user g-pos-rel"></i> Welcome</font> <a class="g-brd-2 g-mr-10 g-mb-15" href="myProfile.php"><b><?= $selectUserInformations['user_fullname'];?>!</b></a>
                <br>

              <!-- Notification Icon Start -->
              <div class="row">
                <div class="col-md-12">
              <ul id="nav">
              <li id="notification_li">
                     <a href="javascript:void(0);" id="notificationLink" class="justify-content-between">
                         <b><span class="u-label g-font-size-18 g-bg-primary g-rounded-20 g-px-8"><i class="icon-bell g-pos-rel g-top-1" ></i>  <span id="notificationCount"></span></span></b>
                     </a>
                     <div id="notificationContainer">
                      <div id="notificationTitle"><i class="icon-cursor"></i> All Notifications</div>
                      <div id="notificationsBody" class="notifications">
                        <?php
                        $getNotficationinPanel = $conn -> query("SELECT * FROM `user_notification_record` WHERE `userID` = $userID");
                        while ($showNotificationsinPanel = $getNotficationinPanel -> fetch_assoc()) {
                          ?>

                          <div class="row">
                            <div class="col-lg-12">
                              <!-- Alert with Box Shadow -->
                                <div class="alert fade show u-shadow-v1-3 g-pa-20" role="alert">
                                  <button type="button" class="close u-alert-close--light g-ml-10 g-mt-1" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                  </button>

                                  <div class="media">
                                    <div class="d-flex g-mr-10">
                                      <span class="u-icon-v3 u-icon-size--sm g-bg-red g-color-white">
                                        <i class="fa fa-magic"></i>
                                      </span>
                                    </div>
                                    <div class="media-body">
                                      <div class="d-flex justify-content-between">
                                        <p class="m-11"><strong><?=$showNotificationsinPanel['notification_title']?></strong> <br><small>sent by <b><?=$showNotificationsinPanel['notification_sent_by']?></b></small>
                                        </p>
                                        <span class="float-right small g-mx-10">Just Now</span>
                                      </div>
                                      <p class="m-0 g-font-size-14"><?=$showNotificationsinPanel['notification_message']?></p>
                                    </div>
                                  </div>
                                </div>
                                <!-- End Alert with Box Shadow -->
                              </div>
                            </div>

                        <?php
                        }
                        ?>
                      </div>
                      <div id="notificationFooter"><a href="#">See All</a></div>
                      </div>
                </li>

              <!-- Notification Icon End -->

              <!-- Wallet Icon Start -->
                    <li>
                     <a href="#" class="justify-content-between">
                         <span class="u-label g-font-size-18 g-bg-blue g-rounded-20 g-px-8"><i class="icon-wallet g-pos-rel g-top-1 g-mr-8"></i>₹<b><?= $selectUserInformations['walletBalance'];?></b></span>
                     </a>
                   </li>
               <!-- Wallet Icon End -->

               <!-- Logout Icon Start -->
                    <li>
                      <a href="../auth/controller/userLogout.php" class="justify-content-between">
                          <span class="u-label g-font-size-18 g-bg-lightred g-rounded-20 g-px-8"><i class="icon-logout g-pos-rel g-top-1 g-mr-8"></i><b>Logoff</b></span>
                      </a>
                    </li>
                <!-- Logout Icon End -->
                </ul>
              </div>
            </div>

             </div>
             <!-- User AREA End-->

           <?php }} ?>
         </nav>
         </div>
        </div>
      </div>
      <!-- Meta, Header and Navigation End-->
